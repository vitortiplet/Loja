<?php
/**
 * Leitor simples de arquivo .env (sem dependências externas).
 * Carrega as variáveis em $_ENV e putenv(); use env('CHAVE', 'padrao').
 */
function carregar_env(string $arquivo): void
{
    if (!is_readable($arquivo)) {
        http_response_code(500);
        exit('Arquivo .env não encontrado. Copie .env.example para .env e configure.');
    }
    foreach (file($arquivo, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $linha) {
        $linha = trim($linha);
        if ($linha === '' || $linha[0] === '#' || strpos($linha, '=') === false) {
            continue;
        }
        [$chave, $valor] = explode('=', $linha, 2);
        $chave = trim($chave);
        $valor = trim($valor, " \t\"'");
        $_ENV[$chave] = $valor;
        putenv("$chave=$valor");
    }
}

function env(string $chave, ?string $padrao = null): ?string
{
    return $_ENV[$chave] ?? $padrao;
}

carregar_env(__DIR__ . '/../.env');
