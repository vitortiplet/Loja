<?php
require_once __DIR__ . '/includes/bootstrap.php';
exigir_login();

$id = (int) ($_GET['id'] ?? 0);

$st = db()->prepare('SELECT id, data_pedido, forma_pagamento, total FROM pedidos WHERE id = :id AND usuario_id = :u');
$st->execute([':id' => $id, ':u' => usuario_atual()['id']]);
$pedido = $st->fetch();
if (!$pedido) {
    redirecionar('index.php');
}

$it = db()->prepare('SELECT ip.quantidade, ip.preco_unitario, p.nome
                     FROM itens_pedido ip JOIN produtos p ON p.id = ip.produto_id
                     WHERE ip.pedido_id = :id');
$it->execute([':id' => $id]);
$itens = $it->fetchAll();
$rotulos = ['pix' => 'PIX', 'boleto' => 'Boleto', 'cartao' => 'Cartão de crédito'];

$titulo = 'Pedido confirmado';
require __DIR__ . '/includes/header.php';
?>
<div class="painel">
  <h1 class="h3">Pedido #<?= (int) $pedido['id'] ?> confirmado</h1>
  <p>Pagamento via <?= e($rotulos[$pedido['forma_pagamento']] ?? $pedido['forma_pagamento']) ?> aprovado em
     <?= e(date('d/m/Y H:i', strtotime($pedido['data_pedido']))) ?>.</p>
  <table class="table tabela-fliper">
    <thead><tr><th>Produto</th><th>Qtd.</th><th>Preço un.</th><th>Subtotal</th></tr></thead>
    <tbody>
    <?php foreach ($itens as $i): ?>
      <tr>
        <td><?= e($i['nome']) ?></td>
        <td><?= (int) $i['quantidade'] ?></td>
        <td><?= e(brl($i['preco_unitario'])) ?></td>
        <td><?= e(brl($i['quantidade'] * $i['preco_unitario'])) ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
    <tfoot><tr><th colspan="3" class="text-end">Total</th><th><?= e(brl($pedido['total'])) ?></th></tr></tfoot>
  </table>
  <a class="btn btn-destaque" href="<?= e(url('index.php')) ?>">Voltar à vitrine</a>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
