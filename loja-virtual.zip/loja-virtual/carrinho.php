<?php
require_once __DIR__ . '/includes/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verificar();
    $acao = $_POST['acao'] ?? '';
    $id = (int) ($_POST['produto_id'] ?? 0);
    $qtd = (int) ($_POST['quantidade'] ?? 1);

    
    $st = db()->prepare('SELECT id, nome, estoque FROM produtos WHERE id = :id AND ativo = 1');
    $st->execute([':id' => $id]);
    $p = $st->fetch();

    if ($acao === 'remover') {
        unset($_SESSION['carrinho'][$id]);
        flash('info', 'Item removido do carrinho.');
    } elseif (!$p) {
        unset($_SESSION['carrinho'][$id]);
        flash('danger', 'Produto indisponível.');
    } elseif ($acao === 'adicionar') {
        $novo = (int) ($_SESSION['carrinho'][$id] ?? 0) + max(1, $qtd);
        if ($p['estoque'] < 1) {
            flash('danger', $p['nome'] . ' está esgotado.');
        } elseif ($novo > $p['estoque']) {
            $_SESSION['carrinho'][$id] = (int) $p['estoque'];
            flash('warning', 'Quantidade ajustada ao estoque disponível de "' . $p['nome'] . '" (' . $p['estoque'] . ').');
        } else {
            $_SESSION['carrinho'][$id] = $novo;
            flash('success', '"' . $p['nome'] . '" adicionado ao carrinho.');
        }
    } elseif ($acao === 'atualizar') {
        if ($qtd < 1) {
            unset($_SESSION['carrinho'][$id]);
            flash('info', 'Item removido do carrinho.');
        } elseif ($qtd > $p['estoque']) {
            $_SESSION['carrinho'][$id] = (int) $p['estoque'];
            flash('warning', 'Só há ' . $p['estoque'] . ' unidade(s) de "' . $p['nome'] . '" em estoque.');
        } else {
            $_SESSION['carrinho'][$id] = $qtd;
        }
    }
    redirecionar('carrinho.php');
}

$c = carrinho_detalhado();
$titulo = 'Carrinho';
require __DIR__ . '/includes/header.php';
?>
<h1 class="h3 mb-3">Seu carrinho</h1>
<?php if (!$c['itens']): ?>
  <div class="painel text-center">
    <p class="mb-2">Seu carrinho está vazio.</p>
    <a class="btn btn-destaque" href="<?= e(url('index.php')) ?>">Ver produtos</a>
  </div>
<?php else: ?>
  <div class="painel">
    <div class="table-responsive">
      <table class="table align-middle tabela-fliper">
        <thead>
          <tr><th>Produto</th><th>Preço</th><th style="width:130px">Qtd.</th><th>Subtotal</th><th></th></tr>
        </thead>
        <tbody>
        <?php foreach ($c['itens'] as $i): ?>
          <tr>
            <td>
              <div class="d-flex align-items-center gap-2">
                <img class="mini-img" src="<?= e(imagem_produto($i)) ?>" alt="">
                <a href="<?= e(url('produto.php?id=' . (int) $i['id'])) ?>"><?= e($i['nome']) ?></a>
              </div>
            </td>
            <td><?= e(brl($i['preco'])) ?></td>
            <td>
              <form method="post">
                <?= csrf_campo() ?>
                <input type="hidden" name="acao" value="atualizar">
                <input type="hidden" name="produto_id" value="<?= (int) $i['id'] ?>">
                <label class="visually-hidden" for="q<?= (int) $i['id'] ?>">Quantidade de <?= e($i['nome']) ?></label>
                <input type="number" id="q<?= (int) $i['id'] ?>" name="quantidade" class="form-control form-control-sm"
                       value="<?= (int) $i['quantidade'] ?>" min="1" max="<?= (int) $i['estoque'] ?>" data-auto-envio>
                <noscript><button class="btn btn-sm btn-contorno mt-1">Atualizar</button></noscript>
              </form>
              <div class="small text-muted">Estoque: <?= (int) $i['estoque'] ?></div>
            </td>
            <td class="fw-bold"><?= e(brl($i['subtotal'])) ?></td>
            <td>
              <form method="post" data-confirmar="Remover este item do carrinho?">
                <?= csrf_campo() ?>
                <input type="hidden" name="acao" value="remover">
                <input type="hidden" name="produto_id" value="<?= (int) $i['id'] ?>">
                <button class="btn btn-sm btn-outline-danger" type="submit">Remover</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mt-2">
      <a href="<?= e(url('index.php')) ?>">Continuar comprando</a>
      <div class="text-end">
        <div class="text-muted">Total geral</div>
        <div class="preco display-6"><?= e(brl($c['total'])) ?></div>
        <a class="btn btn-destaque mt-2" href="<?= e(url('checkout.php')) ?>">Finalizar compra</a>
      </div>
    </div>
  </div>
<?php endif; ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
