<?php
require_once __DIR__ . '/includes/bootstrap.php';


$destinosPermitidos = ['checkout.php', 'carrinho.php', 'admin/index.php'];
$proxima = $_GET['next'] ?? $_POST['next'] ?? '';
if (!in_array($proxima, $destinosPermitidos, true)) {
    $proxima = '';
}

if (usuario_atual()) {
    redirecionar($proxima ?: 'index.php');
}

$erro = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verificar();
    $email = strtolower(trim($_POST['email'] ?? ''));
    $senha = $_POST['senha'] ?? '';

    $st = db()->prepare('SELECT id, nome, email, senha_hash, perfil FROM usuarios WHERE email = :email');
    $st->execute([':email' => $email]);
    $u = $st->fetch();

    if ($u && password_verify($senha, $u['senha_hash'])) {
        session_regenerate_id(true); 
        $_SESSION['usuario'] = [
            'id'     => (int) $u['id'],
            'nome'   => $u['nome'],
            'email'  => $u['email'],
            'perfil' => $u['perfil'],
        ];
        
        if (password_needs_rehash($u['senha_hash'], PASSWORD_DEFAULT)) {
            $up = db()->prepare('UPDATE usuarios SET senha_hash = :h WHERE id = :id');
            $up->execute([':h' => password_hash($senha, PASSWORD_DEFAULT), ':id' => $u['id']]);
        }
        flash('success', 'Bem-vindo(a), ' . $u['nome'] . '!');
        redirecionar($proxima ?: ($u['perfil'] === 'admin' ? 'admin/index.php' : 'index.php'));
    }
    $erro = 'E-mail ou senha incorretos.'; 
}

$titulo = 'Entrar';
require __DIR__ . '/includes/header.php';
?>
<div class="row justify-content-center">
  <div class="col-md-6 col-lg-5">
    <div class="painel">
      <h1 class="h3 mb-3">Entrar</h1>
      <?php if ($erro): ?><div class="alert alert-danger py-2"><?= e($erro) ?></div><?php endif; ?>
      <form method="post">
        <?= csrf_campo() ?>
        <input type="hidden" name="next" value="<?= e($proxima) ?>">
        <div class="mb-3">
          <label class="form-label" for="email">E-mail</label>
          <input class="form-control" type="email" id="email" name="email" value="<?= e($email) ?>" required autofocus>
        </div>
        <div class="mb-3">
          <label class="form-label" for="senha">Senha</label>
          <input class="form-control" type="password" id="senha" name="senha" required>
        </div>
        <button class="btn btn-destaque w-100" type="submit">Entrar</button>
      </form>
      <p class="small mt-3 mb-0">Ainda não tem conta? <a href="<?= e(url('cadastro.php')) ?>">Criar conta</a></p>
    </div>
  </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
