// Confirmação antes de ações destrutivas: <form data-confirmar="Mensagem">
document.querySelectorAll('form[data-confirmar]').forEach(function (form) {
  form.addEventListener('submit', function (ev) {
    if (!window.confirm(form.dataset.confirmar)) {
      ev.preventDefault();
    }
  });
});

// Atualiza o carrinho automaticamente ao mudar a quantidade
document.querySelectorAll('input[data-auto-envio]').forEach(function (campo) {
  campo.addEventListener('change', function () {
    campo.form.submit();
  });
});

// Prévia da imagem escolhida no formulário de produto
var arquivo = document.getElementById('imagem');
var previa = document.getElementById('previa');
if (arquivo && previa) {
  arquivo.addEventListener('change', function () {
    if (arquivo.files && arquivo.files[0]) {
      previa.src = URL.createObjectURL(arquivo.files[0]);
      previa.classList.remove('d-none');
    }
  });
}
