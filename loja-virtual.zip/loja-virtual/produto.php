<?php
require_once __DIR__ . '/includes/bootstrap.php';

$id = (int) ($_GET['id'] ?? 0);
$st = db()->prepare('SELECT p.*, c.nome AS categoria FROM produtos p
                     JOIN categorias c ON c.id = p.categoria_id
                     WHERE p.id = :id AND p.ativo = 1');
$st->execute([':id' => $id]);
$p = $st->fetch();

if (!$p) {
    http_response_code(404);
    $titulo = 'Produto não encontrado';
    require __DIR__ . '/includes/header.php';
    echo '<div class="painel text-center"><p>Produto não encontrado.</p><a href="' . e(url('index.php')) . '">Voltar à vitrine</a></div>';
    require __DIR__ . '/includes/footer.php';
    exit;
}

$noCarrinho = (int) ($_SESSION['carrinho'][$p['id']] ?? 0);
$titulo = $p['nome'];
require __DIR__ . '/includes/header.php';
?>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?= e(url('index.php')) ?>">Vitrine</a></li>
    <li class="breadcrumb-item"><a href="<?= e(url('index.php?categoria=' . (int) $p['categoria_id'])) ?>"><?= e($p['categoria']) ?></a></li>
    <li class="breadcrumb-item active" aria-current="page"><?= e($p['nome']) ?></li>
  </ol>
</nav>

<div class="row g-4">
  <div class="col-md-6">
    <img class="img-fluid rounded-3 border" src="<?= e(imagem_produto($p)) ?>" alt="<?= e($p['nome']) ?>">
  </div>
  <div class="col-md-6">
    <span class="etiqueta"><?= e($p['categoria']) ?> · Código #<?= (int) $p['id'] ?></span>
    <h1 class="h2 mt-1"><?= e($p['nome']) ?></h1>
    <p class="preco display-6"><?= e(brl($p['preco'])) ?></p>
    <p><?= nl2br(e($p['descricao'])) ?></p>

    <?php if ($p['estoque'] > 0): ?>
      <p class="<?= $p['estoque'] <= 5 ? 'estoque-baixo' : 'estoque-ok' ?>">
        <?= $p['estoque'] <= 5 ? 'Últimas ' . (int) $p['estoque'] . ' unidades' : 'Em estoque (' . (int) $p['estoque'] . ' unidades)' ?>
      </p>
      <form method="post" action="<?= e(url('carrinho.php')) ?>" class="row g-2 align-items-end">
        <?= csrf_campo() ?>
        <input type="hidden" name="acao" value="adicionar">
        <input type="hidden" name="produto_id" value="<?= (int) $p['id'] ?>">
        <div class="col-4 col-sm-3">
          <label for="quantidade" class="form-label">Quantidade</label>
          <input type="number" id="quantidade" name="quantidade" class="form-control" value="1" min="1" max="<?= (int) $p['estoque'] ?>" required>
        </div>
        <div class="col-8 col-sm-6">
          <button class="btn btn-destaque w-100" type="submit">Adicionar ao carrinho</button>
        </div>
      </form>
      <?php if ($noCarrinho): ?>
        <p class="small mt-2 mb-0">Você já tem <?= $noCarrinho ?> no carrinho.</p>
      <?php endif; ?>
    <?php else: ?>
      <p class="estoque-zero">Produto esgotado.</p>
      <button class="btn btn-secondary" disabled>Indisponível</button>
    <?php endif; ?>
  </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
