<?php
require_once __DIR__ . '/includes/bootstrap.php';

if (usuario_atual()) {
    redirecionar('index.php');
}

$erros = [];
$nome = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verificar();
    $nome = trim($_POST['nome'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $senha = $_POST['senha'] ?? '';
    $confirma = $_POST['confirma'] ?? '';

    if ($nome === '' || mb_strlen($nome) > 100) {
        $erros[] = 'Informe seu nome (até 100 caracteres).';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($email) > 150) {
        $erros[] = 'Informe um e-mail válido.';
    }
    if (strlen($senha) < 8) {
        $erros[] = 'A senha deve ter pelo menos 8 caracteres.';
    }
    if ($senha !== $confirma) {
        $erros[] = 'As senhas não conferem.';
    }

    if (!$erros) {
        try {
            
            $st = db()->prepare('INSERT INTO usuarios (nome, email, senha_hash, perfil)
                                 VALUES (:nome, :email, :hash, :perfil)');
            $st->execute([
                ':nome'   => $nome,
                ':email'  => $email,
                ':hash'   => password_hash($senha, PASSWORD_DEFAULT),
                ':perfil' => 'cliente',
            ]);
            flash('success', 'Conta criada! Agora é só entrar.');
            redirecionar('login.php');
        } catch (PDOException $ex) {
            if ($ex->getCode() === '23000') {        
                $erros[] = 'Este e-mail já está cadastrado.';
            } else {
                error_log($ex->getMessage());
                $erros[] = 'Não foi possível criar a conta agora. Tente novamente.';
            }
        }
    }
}

$titulo = 'Criar conta';
require __DIR__ . '/includes/header.php';
?>
<div class="row justify-content-center">
  <div class="col-md-6 col-lg-5">
    <div class="painel">
      <h1 class="h3 mb-3">Criar conta</h1>
      <?php foreach ($erros as $erro): ?>
        <div class="alert alert-danger py-2"><?= e($erro) ?></div>
      <?php endforeach; ?>
      <form method="post" novalidate>
        <?= csrf_campo() ?>
        <div class="mb-3">
          <label class="form-label" for="nome">Nome</label>
          <input class="form-control" id="nome" name="nome" value="<?= e($nome) ?>" required maxlength="100">
        </div>
        <div class="mb-3">
          <label class="form-label" for="email">E-mail</label>
          <input class="form-control" type="email" id="email" name="email" value="<?= e($email) ?>" required maxlength="150">
        </div>
        <div class="mb-3">
          <label class="form-label" for="senha">Senha (mínimo 8 caracteres)</label>
          <input class="form-control" type="password" id="senha" name="senha" required minlength="8">
        </div>
        <div class="mb-3">
          <label class="form-label" for="confirma">Confirmar senha</label>
          <input class="form-control" type="password" id="confirma" name="confirma" required minlength="8">
        </div>
        <button class="btn btn-destaque w-100" type="submit">Criar conta</button>
      </form>
      <p class="small mt-3 mb-0">Já tem conta? <a href="<?= e(url('login.php')) ?>">Entrar</a></p>
    </div>
  </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
