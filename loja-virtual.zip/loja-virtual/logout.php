<?php
require_once __DIR__ . '/includes/bootstrap.php';


$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $c = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $c['path'], $c['domain'], $c['secure'], $c['httponly']);
}
session_destroy();

session_start();
flash('info', 'Você saiu da sua conta.');
redirecionar('index.php');
