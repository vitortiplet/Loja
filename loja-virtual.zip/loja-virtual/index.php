<?php
require_once __DIR__ . '/includes/bootstrap.php';

$busca = trim($_GET['q'] ?? '');
$categoriaId = (int) ($_GET['categoria'] ?? 0);

$categorias = db()->query('SELECT id, nome FROM categorias ORDER BY nome')->fetchAll();


$condicoes = ['p.ativo = 1'];
$params = [];
if ($categoriaId > 0) {
    $condicoes[] = 'p.categoria_id = :cat';
    $params[':cat'] = $categoriaId;
}
if ($busca !== '') {
    $condicoes[] = '(p.nome LIKE :q1 OR p.descricao LIKE :q2)';
    $params[':q1'] = '%' . $busca . '%';
    $params[':q2'] = '%' . $busca . '%';
}
$sql = 'SELECT p.id, p.nome, p.preco, p.estoque, p.imagem, c.nome AS categoria
        FROM produtos p JOIN categorias c ON c.id = p.categoria_id
        WHERE ' . implode(' AND ', $condicoes) . ' ORDER BY p.nome';
$st = db()->prepare($sql);
$st->execute($params);
$produtos = $st->fetchAll();

$titulo = 'Vitrine';
require __DIR__ . '/includes/header.php';
?>
<section class="hero">
  <h1>Tudo para o seu próximo nível.</h1>
  <p>Consoles, jogos e acessórios com estoque atualizado em tempo real.</p>
</section>

<form class="row g-2 mb-4" method="get" action="<?= e(url('index.php')) ?>">
  <div class="col-md-5">
    <label class="visually-hidden" for="q">Buscar produto</label>
    <input type="search" id="q" name="q" class="form-control" placeholder="Buscar por nome ou descrição" value="<?= e($busca) ?>">
  </div>
  <div class="col-md-4">
    <label class="visually-hidden" for="categoria">Categoria</label>
    <select id="categoria" name="categoria" class="form-select">
      <option value="0">Todas as categorias</option>
      <?php foreach ($categorias as $c): ?>
        <option value="<?= (int) $c['id'] ?>" <?= $categoriaId === (int) $c['id'] ? 'selected' : '' ?>><?= e($c['nome']) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="col-md-3 d-flex gap-2">
    <button class="btn btn-destaque flex-fill" type="submit">Filtrar</button>
    <a class="btn btn-contorno" href="<?= e(url('index.php')) ?>">Limpar</a>
  </div>
</form>

<?php if (!$produtos): ?>
  <div class="painel text-center">
    <p class="mb-2">Nenhum produto encontrado para esse filtro.</p>
    <a href="<?= e(url('index.php')) ?>">Ver todos os produtos</a>
  </div>
<?php else: ?>
<div class="row row-cols-1 row-cols-sm-2 row-cols-lg-4 g-3">
  <?php foreach ($produtos as $p): ?>
    <div class="col">
      <article class="cartao-produto">
        <a href="<?= e(url('produto.php?id=' . (int) $p['id'])) ?>">
          <img src="<?= e(imagem_produto($p)) ?>" alt="<?= e($p['nome']) ?>" loading="lazy">
        </a>
        <div class="corpo">
          <span class="etiqueta"><?= e($p['categoria']) ?></span>
          <a class="nome" href="<?= e(url('produto.php?id=' . (int) $p['id'])) ?>"><?= e($p['nome']) ?></a>
          <span class="preco"><?= e(brl($p['preco'])) ?></span>
          <?php if ($p['estoque'] > 0): ?>
            <span class="<?= $p['estoque'] <= 5 ? 'estoque-baixo' : 'estoque-ok' ?> small">
              <?= $p['estoque'] <= 5 ? 'Últimas ' . (int) $p['estoque'] . ' unidades' : 'Em estoque' ?>
            </span>
            <form method="post" action="<?= e(url('carrinho.php')) ?>" class="mt-auto pt-2">
              <?= csrf_campo() ?>
              <input type="hidden" name="acao" value="adicionar">
              <input type="hidden" name="produto_id" value="<?= (int) $p['id'] ?>">
              <input type="hidden" name="quantidade" value="1">
              <button class="btn btn-destaque w-100" type="submit">Adicionar ao carrinho</button>
            </form>
          <?php else: ?>
            <span class="estoque-zero small">Esgotado</span>
            <button class="btn btn-secondary w-100 mt-auto" disabled>Indisponível</button>
          <?php endif; ?>
        </div>
      </article>
    </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
