-- Fliperama Games - schema e carga inicial
-- Importe pelo phpMyAdmin (aba Importar) ou: mysql -u root < database/schema.sql

CREATE DATABASE IF NOT EXISTS loja_games
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE loja_games;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS itens_pedido;
DROP TABLE IF EXISTS pedidos;
DROP TABLE IF EXISTS produtos;
DROP TABLE IF EXISTS categorias;
DROP TABLE IF EXISTS usuarios;
SET FOREIGN_KEY_CHECKS = 1;

-- Clientes e administradores (senha_hash guarda o resultado de password_hash())
CREATE TABLE usuarios (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nome        VARCHAR(100) NOT NULL,
  email       VARCHAR(150) NOT NULL,
  senha_hash  VARCHAR(255) NOT NULL,
  perfil      ENUM('cliente','admin') NOT NULL DEFAULT 'cliente',
  criado_em   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_usuarios_email (email)
) ENGINE=InnoDB;

CREATE TABLE categorias (
  id    INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nome  VARCHAR(80) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_categorias_nome (nome)
) ENGINE=InnoDB;

CREATE TABLE produtos (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  categoria_id  INT UNSIGNED NOT NULL,
  nome          VARCHAR(150) NOT NULL,
  descricao     TEXT NOT NULL,
  preco         DECIMAL(10,2) NOT NULL,
  estoque       INT UNSIGNED NOT NULL DEFAULT 0,
  imagem        VARCHAR(255) NULL,
  ativo         TINYINT(1) NOT NULL DEFAULT 1,
  criado_em     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_produtos_categoria (categoria_id),
  CONSTRAINT fk_produtos_categoria FOREIGN KEY (categoria_id)
    REFERENCES categorias (id) ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT ck_produtos_preco CHECK (preco >= 0)
) ENGINE=InnoDB;

CREATE TABLE pedidos (
  id               INT UNSIGNED NOT NULL AUTO_INCREMENT,
  usuario_id       INT UNSIGNED NOT NULL,
  data_pedido      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  forma_pagamento  ENUM('pix','boleto','cartao') NOT NULL,
  total            DECIMAL(10,2) NOT NULL,
  PRIMARY KEY (id),
  KEY idx_pedidos_usuario (usuario_id),
  CONSTRAINT fk_pedidos_usuario FOREIGN KEY (usuario_id)
    REFERENCES usuarios (id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

-- Resolve a relação N:N entre pedidos e produtos.
-- preco_unitario "congela" o valor praticado no momento da compra.
CREATE TABLE itens_pedido (
  id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
  pedido_id       INT UNSIGNED NOT NULL,
  produto_id      INT UNSIGNED NOT NULL,
  quantidade      INT UNSIGNED NOT NULL,
  preco_unitario  DECIMAL(10,2) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_item_pedido_produto (pedido_id, produto_id),
  KEY idx_itens_produto (produto_id),
  CONSTRAINT fk_itens_pedido FOREIGN KEY (pedido_id)
    REFERENCES pedidos (id) ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_itens_produto FOREIGN KEY (produto_id)
    REFERENCES produtos (id) ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT ck_itens_qtd CHECK (quantidade > 0)
) ENGINE=InnoDB;

-- ===== Carga inicial de teste =====
-- admin@fliperama.com / Admin@123   |   cliente@fliperama.com / Cliente@123
INSERT INTO usuarios (nome, email, senha_hash, perfil) VALUES
('Administrador', 'admin@fliperama.com',   '$2b$12$TmTqlMyC.Xytn8BrgyX9FO1MBxJKs6W/K2.gcybXlyxUpxibX9QH6', 'admin'),
('Cliente Teste', 'cliente@fliperama.com', '$2b$12$j/31ypva66jrlqo0rM04HOD2olBhzr0V9ajiSllwHNZyyfs2EsWJW', 'cliente');

INSERT INTO categorias (nome) VALUES
('Consoles'), ('Jogos'), ('Acessórios'), ('Colecionáveis');

INSERT INTO produtos (categoria_id, nome, descricao, preco, estoque) VALUES
(1, 'Console Nova X',           'Console de nova geração com SSD ultrarrápido, 4K a 120 fps e controle sem fio incluso.', 3899.90, 8),
(1, 'Console Retro Mini',       'Clássico em miniatura com 200 jogos 8 e 16 bits já instalados. Saída HDMI.',             499.90, 15),
(1, 'Portátil Pocket Pro',      'Portátil com tela OLED de 7 polegadas e 10 horas de bateria.',                          2799.00, 5),
(2, 'Dragões de Aurora',        'RPG de mundo aberto com mais de 80 horas de campanha e modo cooperativo.',               249.90, 30),
(2, 'Velocidade Total GT',      'Corrida realista com mais de 400 carros e pistas licenciadas.',                          199.90, 22),
(2, 'Pixel Quest',              'Aventura de plataforma em pixel art, com trilha sonora original.',                        79.90, 50),
(2, 'Arena Tática',             'Estratégia por turnos com partidas online ranqueadas.',                                  149.90, 0),
(3, 'Controle Sem Fio Pro',     'Controle ergonômico com gatilhos ajustáveis e bateria de 40 horas.',                     399.90, 18),
(3, 'Headset Surround 7.1',     'Headset com microfone removível e almofadas de espuma viscoelástica.',                   349.90, 12),
(3, 'Teclado Mecânico RGB',     'Teclado com switches vermelhos, iluminação por tecla e layout ABNT2.',                   459.90, 9),
(4, 'Action Figure Herói 25cm', 'Figura articulada de 25 cm, edição limitada numerada.',                                  289.90, 6),
(4, 'Camiseta Pixel Heart',     'Camiseta 100% algodão com estampa de coração em pixel art.',                              89.90, 40);
