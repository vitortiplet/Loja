<?php
require_once __DIR__ . '/_inicio.php';
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verificar();
    $acao = $_POST['acao'] ?? '';
    $id = (int) ($_POST['id'] ?? 0);

    if ($acao === 'alternar') {
        $st = $pdo->prepare('UPDATE produtos SET ativo = 1 - ativo WHERE id = :id');
        $st->execute([':id' => $id]);
        flash('success', 'Status do produto atualizado.');
    } elseif ($acao === 'excluir') {
        $img = $pdo->prepare('SELECT imagem FROM produtos WHERE id = :id');
        $img->execute([':id' => $id]);
        $arquivo = $img->fetchColumn();
        try {
            $st = $pdo->prepare('DELETE FROM produtos WHERE id = :id');
            $st->execute([':id' => $id]);
            if ($arquivo) {
                @unlink(__DIR__ . '/../assets/img/produtos/' . basename($arquivo));
            }
            flash('success', 'Produto excluído.');
        } catch (PDOException $ex) {
            if ($ex->getCode() === '23000') {
                // já existe em pedidos: preserva o histórico apenas desativando
                $st = $pdo->prepare('UPDATE produtos SET ativo = 0 WHERE id = :id');
                $st->execute([':id' => $id]);
                flash('warning', 'Este produto já foi vendido, então foi desativado em vez de excluído.');
            } else {
                error_log($ex->getMessage());
                flash('danger', 'Não foi possível excluir o produto.');
            }
        }
    }
    redirecionar('admin/produtos.php');
}

$produtos = $pdo->query('SELECT p.id, p.nome, p.preco, p.estoque, p.imagem, p.ativo, c.nome AS categoria
                         FROM produtos p JOIN categorias c ON c.id = p.categoria_id
                         ORDER BY p.id DESC')->fetchAll();

$titulo = 'Produtos (admin)';
require __DIR__ . '/../includes/header.php';
?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h1 class="h3 mb-0">Painel administrativo</h1>
  <a class="btn btn-destaque" href="<?= e(url('admin/produto_form.php')) ?>">Cadastrar produto</a>
</div>
<?php menu_admin('produtos'); ?>
<div class="painel">
  <div class="table-responsive">
    <table class="table align-middle tabela-fliper">
      <thead><tr><th>Produto</th><th>Categoria</th><th>Preço</th><th>Estoque</th><th>Status</th><th>Ações</th></tr></thead>
      <tbody>
      <?php foreach ($produtos as $p): ?>
        <tr class="<?= $p['ativo'] ? '' : 'text-muted' ?>">
          <td>
            <div class="d-flex align-items-center gap-2">
              <img class="mini-img" src="<?= e(imagem_produto($p)) ?>" alt="">
              <span>#<?= (int) $p['id'] ?> · <?= e($p['nome']) ?></span>
            </div>
          </td>
          <td><?= e($p['categoria']) ?></td>
          <td><?= e(brl($p['preco'])) ?></td>
          <td><?= (int) $p['estoque'] ?></td>
          <td><?= $p['ativo'] ? 'Ativo' : 'Inativo' ?></td>
          <td>
            <div class="d-flex flex-wrap gap-1">
              <a class="btn btn-sm btn-contorno" href="<?= e(url('admin/produto_form.php?id=' . (int) $p['id'])) ?>">Editar</a>
              <form method="post">
                <?= csrf_campo() ?>
                <input type="hidden" name="acao" value="alternar">
                <input type="hidden" name="id" value="<?= (int) $p['id'] ?>">
                <button class="btn btn-sm btn-outline-secondary" type="submit"><?= $p['ativo'] ? 'Desativar' : 'Ativar' ?></button>
              </form>
              <form method="post" data-confirmar="Excluir &quot;<?= e($p['nome']) ?>&quot;? Essa ação não pode ser desfeita.">
                <?= csrf_campo() ?>
                <input type="hidden" name="acao" value="excluir">
                <input type="hidden" name="id" value="<?= (int) $p['id'] ?>">
                <button class="btn btn-sm btn-outline-danger" type="submit">Excluir</button>
              </form>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
