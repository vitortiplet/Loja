<?php
require_once __DIR__ . '/_inicio.php';
$pdo = db();

$id = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
$produto = ['nome' => '', 'categoria_id' => 0, 'descricao' => '', 'preco' => '', 'estoque' => 0, 'imagem' => null, 'ativo' => 1];

if ($id > 0) {
    $st = $pdo->prepare('SELECT * FROM produtos WHERE id = :id');
    $st->execute([':id' => $id]);
    $encontrado = $st->fetch();
    if (!$encontrado) {
        flash('danger', 'Produto não encontrado.');
        redirecionar('admin/produtos.php');
    }
    $produto = $encontrado;
}
$categorias = $pdo->query('SELECT id, nome FROM categorias ORDER BY nome')->fetchAll();
$erros = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verificar();
    $produto['nome'] = trim($_POST['nome'] ?? '');
    $produto['categoria_id'] = (int) ($_POST['categoria_id'] ?? 0);
    $produto['descricao'] = trim($_POST['descricao'] ?? '');
    $precoTexto = str_replace(',', '.', trim($_POST['preco'] ?? ''));
    $produto['preco'] = $precoTexto;
    $produto['estoque'] = $_POST['estoque'] ?? '';
    $produto['ativo'] = isset($_POST['ativo']) ? 1 : 0;

    if ($produto['nome'] === '' || mb_strlen($produto['nome']) > 150) {
        $erros[] = 'Informe o nome (até 150 caracteres).';
    }
    if (!in_array($produto['categoria_id'], array_column($categorias, 'id'), false)) {
        $erros[] = 'Selecione uma categoria válida.';
    }
    if ($produto['descricao'] === '') {
        $erros[] = 'Informe a descrição.';
    }
    if (!is_numeric($precoTexto) || (float) $precoTexto < 0 || (float) $precoTexto > 99999999.99) {
        $erros[] = 'Informe um preço válido (ex.: 199,90).';
    }
    if (filter_var($produto['estoque'], FILTER_VALIDATE_INT, ['options' => ['min_range' => 0]]) === false) {
        $erros[] = 'O estoque deve ser um número inteiro maior ou igual a zero.';
    }

    // Upload opcional da imagem
    $novaImagem = null;
    $arq = $_FILES['imagem'] ?? null;
    if ($arq && $arq['error'] !== UPLOAD_ERR_NO_FILE) {
        $tipos = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
        if ($arq['error'] !== UPLOAD_ERR_OK) {
            $erros[] = 'Falha no envio da imagem.';
        } elseif ($arq['size'] > 2 * 1024 * 1024) {
            $erros[] = 'A imagem deve ter no máximo 2 MB.';
        } else {
            $mime = (new finfo(FILEINFO_MIME_TYPE))->file($arq['tmp_name']); // confere o conteúdo real
            if (!isset($tipos[$mime])) {
                $erros[] = 'Envie uma imagem JPG, PNG ou WEBP.';
            } else {
                $novaImagem = bin2hex(random_bytes(12)) . '.' . $tipos[$mime];
            }
        }
    }

    if (!$erros) {
        $pasta = __DIR__ . '/../assets/img/produtos/';
        if ($novaImagem) {
            if (!move_uploaded_file($arq['tmp_name'], $pasta . $novaImagem)) {
                $erros[] = 'Não foi possível salvar a imagem.';
            }
        }
    }

    if (!$erros) {
        $imagemFinal = $novaImagem ?: $produto['imagem'];
        $dados = [
            ':cat' => $produto['categoria_id'], ':nome' => $produto['nome'], ':desc' => $produto['descricao'],
            ':preco' => number_format((float) $precoTexto, 2, '.', ''), ':est' => (int) $produto['estoque'],
            ':img' => $imagemFinal, ':ativo' => $produto['ativo'],
        ];
        if ($id > 0) {
            $antiga = $pdo->prepare('SELECT imagem FROM produtos WHERE id = :id');
            $antiga->execute([':id' => $id]);
            $imagemAntiga = $antiga->fetchColumn();

            $dados[':id'] = $id;
            $st = $pdo->prepare('UPDATE produtos SET categoria_id = :cat, nome = :nome, descricao = :desc,
                                 preco = :preco, estoque = :est, imagem = :img, ativo = :ativo WHERE id = :id');
            $st->execute($dados);
            if ($novaImagem && $imagemAntiga) {
                @unlink($pasta . basename($imagemAntiga));
            }
            flash('success', 'Produto atualizado.');
        } else {
            $st = $pdo->prepare('INSERT INTO produtos (categoria_id, nome, descricao, preco, estoque, imagem, ativo)
                                 VALUES (:cat, :nome, :desc, :preco, :est, :img, :ativo)');
            $st->execute($dados);
            flash('success', 'Produto cadastrado.');
        }
        redirecionar('admin/produtos.php');
    }
}

$titulo = $id > 0 ? 'Editar produto' : 'Cadastrar produto';
require __DIR__ . '/../includes/header.php';
?>
<h1 class="h3 mb-3"><?= e($titulo) ?></h1>
<?php menu_admin('produtos'); ?>
<div class="painel">
  <?php foreach ($erros as $erro): ?><div class="alert alert-danger py-2"><?= e($erro) ?></div><?php endforeach; ?>
  <form method="post" enctype="multipart/form-data" class="row g-3">
    <?= csrf_campo() ?>
    <input type="hidden" name="id" value="<?= (int) $id ?>">
    <div class="col-md-8">
      <label class="form-label" for="nome">Nome</label>
      <input class="form-control" id="nome" name="nome" maxlength="150" required value="<?= e($produto['nome']) ?>">
    </div>
    <div class="col-md-4">
      <label class="form-label" for="categoria_id">Categoria</label>
      <select class="form-select" id="categoria_id" name="categoria_id" required>
        <option value="">Selecione</option>
        <?php foreach ($categorias as $c): ?>
          <option value="<?= (int) $c['id'] ?>" <?= (int) $produto['categoria_id'] === (int) $c['id'] ? 'selected' : '' ?>><?= e($c['nome']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-12">
      <label class="form-label" for="descricao">Descrição</label>
      <textarea class="form-control" id="descricao" name="descricao" rows="4" required><?= e($produto['descricao']) ?></textarea>
    </div>
    <div class="col-6 col-md-3">
      <label class="form-label" for="preco">Preço (R$)</label>
      <input class="form-control" id="preco" name="preco" inputmode="decimal" required value="<?= e($produto['preco']) ?>">
    </div>
    <div class="col-6 col-md-3">
      <label class="form-label" for="estoque">Estoque</label>
      <input class="form-control" type="number" min="0" id="estoque" name="estoque" required value="<?= e($produto['estoque']) ?>">
    </div>
    <div class="col-md-6">
      <label class="form-label" for="imagem">Imagem (JPG, PNG ou WEBP, até 2 MB)</label>
      <input class="form-control" type="file" id="imagem" name="imagem" accept="image/jpeg,image/png,image/webp">
    </div>
    <div class="col-12 d-flex align-items-center gap-3">
      <img id="previa" class="mini-img <?= empty($produto['imagem']) ? 'd-none' : '' ?>" style="width:96px;height:96px"
           src="<?= e(empty($produto['imagem']) ? '' : imagem_produto($produto)) ?>" alt="Imagem atual do produto">
      <div class="form-check">
        <input class="form-check-input" type="checkbox" id="ativo" name="ativo" value="1" <?= $produto['ativo'] ? 'checked' : '' ?>>
        <label class="form-check-label" for="ativo">Produto ativo (visível na loja)</label>
      </div>
    </div>
    <div class="col-12 d-flex gap-2">
      <button class="btn btn-destaque" type="submit">Salvar produto</button>
      <a class="btn btn-contorno" href="<?= e(url('admin/produtos.php')) ?>">Cancelar</a>
    </div>
  </form>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
