<?php
require_once __DIR__ . '/_inicio.php';
$pdo = db();

$pedidos = $pdo->query('SELECT p.id, p.data_pedido, p.forma_pagamento, p.total, u.nome AS cliente, u.email
                        FROM pedidos p JOIN usuarios u ON u.id = p.usuario_id
                        ORDER BY p.id DESC LIMIT 200')->fetchAll();

// Itens de todos os pedidos listados, em uma única consulta
$itensPorPedido = [];
if ($pedidos) {
    $ids = array_column($pedidos, 'id');
    $marcadores = implode(',', array_fill(0, count($ids), '?'));
    $st = $pdo->prepare("SELECT ip.pedido_id, ip.quantidade, ip.preco_unitario, pr.nome
                         FROM itens_pedido ip JOIN produtos pr ON pr.id = ip.produto_id
                         WHERE ip.pedido_id IN ($marcadores) ORDER BY ip.id");
    $st->execute($ids);
    foreach ($st->fetchAll() as $linha) {
        $itensPorPedido[$linha['pedido_id']][] = $linha;
    }
}
$rotulos = ['pix' => 'PIX', 'boleto' => 'Boleto', 'cartao' => 'Cartão'];

$titulo = 'Pedidos (admin)';
require __DIR__ . '/../includes/header.php';
?>
<h1 class="h3 mb-3">Painel administrativo</h1>
<?php menu_admin('pedidos'); ?>
<?php if (!$pedidos): ?>
  <div class="painel text-center">Nenhum pedido realizado ainda.</div>
<?php else: ?>
  <div class="painel">
    <div class="table-responsive">
      <table class="table align-top tabela-fliper">
        <thead><tr><th>Pedido</th><th>Data</th><th>Cliente</th><th>Pagamento</th><th>Itens</th><th class="text-end">Total</th></tr></thead>
        <tbody>
        <?php foreach ($pedidos as $p): ?>
          <tr>
            <td>#<?= (int) $p['id'] ?></td>
            <td><?= e(date('d/m/Y H:i', strtotime($p['data_pedido']))) ?></td>
            <td><?= e($p['cliente']) ?><div class="small text-muted"><?= e($p['email']) ?></div></td>
            <td><?= e($rotulos[$p['forma_pagamento']] ?? $p['forma_pagamento']) ?></td>
            <td>
              <ul class="list-unstyled mb-0 small">
                <?php foreach ($itensPorPedido[$p['id']] ?? [] as $i): ?>
                  <li><?= (int) $i['quantidade'] ?> × <?= e($i['nome']) ?> (<?= e(brl($i['preco_unitario'])) ?>)</li>
                <?php endforeach; ?>
              </ul>
            </td>
            <td class="text-end fw-bold"><?= e(brl($p['total'])) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
<?php endif; ?>
<?php require __DIR__ . '/../includes/footer.php'; ?>
