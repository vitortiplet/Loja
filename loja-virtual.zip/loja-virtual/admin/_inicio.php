<?php
/** Incluído no topo de TODA página do /admin: bloqueia quem não é administrador. */
require_once __DIR__ . '/../includes/bootstrap.php';
exigir_admin();

function menu_admin(string $ativa): void
{
    $links = [
        'index'    => ['admin/index.php', 'Resumo'],
        'produtos' => ['admin/produtos.php', 'Produtos'],
        'pedidos'  => ['admin/pedidos.php', 'Pedidos'],
    ];
    echo '<ul class="nav nav-pills mb-4">';
    foreach ($links as $chave => [$destino, $rotulo]) {
        $classe = $chave === $ativa ? 'nav-link active' : 'nav-link';
        echo '<li class="nav-item"><a class="' . $classe . '" href="' . e(url($destino)) . '">' . e($rotulo) . '</a></li>';
    }
    echo '</ul>';
}
