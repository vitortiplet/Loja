<?php
require_once __DIR__ . '/_inicio.php';

$pdo = db();
$resumo = [
    'Produtos ativos'   => $pdo->query('SELECT COUNT(*) FROM produtos WHERE ativo = 1')->fetchColumn(),
    'Produtos sem estoque' => $pdo->query('SELECT COUNT(*) FROM produtos WHERE ativo = 1 AND estoque = 0')->fetchColumn(),
    'Pedidos realizados' => $pdo->query('SELECT COUNT(*) FROM pedidos')->fetchColumn(),
    'Faturamento'       => brl($pdo->query('SELECT COALESCE(SUM(total),0) FROM pedidos')->fetchColumn()),
];

$titulo = 'Painel administrativo';
require __DIR__ . '/../includes/header.php';
?>
<h1 class="h3 mb-3">Painel administrativo</h1>
<?php menu_admin('index'); ?>
<div class="row g-3">
  <?php foreach ($resumo as $rotulo => $valor): ?>
    <div class="col-6 col-lg-3">
      <div class="painel h-100">
        <div class="text-muted small"><?= e($rotulo) ?></div>
        <div class="fs-3 fw-bold"><?= e($valor) ?></div>
      </div>
    </div>
  <?php endforeach; ?>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
