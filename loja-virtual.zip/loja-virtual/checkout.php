<?php
require_once __DIR__ . '/includes/bootstrap.php';

exigir_login('checkout.php'); 

if (!($_SESSION['carrinho'] ?? [])) {
    flash('warning', 'Seu carrinho está vazio.');
    redirecionar('carrinho.php');
}

$metodos = ['pix' => 'PIX', 'boleto' => 'Boleto', 'cartao' => 'Cartão de crédito'];


class ErroCompra extends Exception {}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verificar();
    $metodo = $_POST['pagamento'] ?? '';
    if (!isset($metodos[$metodo])) {
        flash('danger', 'Selecione uma forma de pagamento.');
        redirecionar('checkout.php');
    }

    $pdo = db();
    try {
        $pdo->beginTransaction();

        $ids = array_map('intval', array_keys($_SESSION['carrinho']));
        sort($ids); 

        $busca = $pdo->prepare('SELECT id, nome, preco, estoque FROM produtos WHERE id = :id AND ativo = 1 FOR UPDATE');
        $linhas = [];
        $total = 0.0;
        foreach ($ids as $id) {
            $busca->execute([':id' => $id]);
            $p = $busca->fetch();
            $qtd = (int) $_SESSION['carrinho'][$id];
            if (!$p) {
                throw new ErroCompra('Um dos produtos do carrinho não está mais disponível.');
            }
            if ($qtd < 1 || $qtd > $p['estoque']) {
                throw new ErroCompra('Estoque insuficiente para "' . $p['nome'] . '" (disponível: ' . $p['estoque'] . ').');
            }
            $linhas[] = ['id' => $id, 'qtd' => $qtd, 'preco' => $p['preco']]; 
            $total += (float) $p['preco'] * $qtd;
        }

        
        $ped = $pdo->prepare('INSERT INTO pedidos (usuario_id, forma_pagamento, total) VALUES (:u, :f, :t)');
        $ped->execute([':u' => usuario_atual()['id'], ':f' => $metodo, ':t' => round($total, 2)]);
        $pedidoId = (int) $pdo->lastInsertId();

        
        $item = $pdo->prepare('INSERT INTO itens_pedido (pedido_id, produto_id, quantidade, preco_unitario)
                               VALUES (:ped, :prod, :qtd, :preco)');
        $baixa = $pdo->prepare('UPDATE produtos SET estoque = estoque - :qtd WHERE id = :id AND estoque >= :minimo');
        foreach ($linhas as $l) {
            $item->execute([':ped' => $pedidoId, ':prod' => $l['id'], ':qtd' => $l['qtd'], ':preco' => $l['preco']]);
            $baixa->execute([':qtd' => $l['qtd'], ':id' => $l['id'], ':minimo' => $l['qtd']]);
            if ($baixa->rowCount() !== 1) {
                throw new ErroCompra('Estoque insuficiente. Revise seu carrinho.');
            }
        }

        $pdo->commit();

        
        unset($_SESSION['carrinho']);
        $_SESSION['ultimo_pedido'] = $pedidoId;
        redirecionar('pedido_sucesso.php?id=' . $pedidoId);
    } catch (ErroCompra $ex) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        flash('danger', $ex->getMessage());
        redirecionar('carrinho.php');
    } catch (Throwable $ex) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log('Falha no checkout: ' . $ex->getMessage());
        flash('danger', 'Não foi possível concluir o pedido. Nada foi cobrado; tente novamente.');
        redirecionar('checkout.php');
    }
}

$c = carrinho_detalhado();
if (!$c['itens']) {
    redirecionar('carrinho.php');
}
$titulo = 'Finalizar compra';
require __DIR__ . '/includes/header.php';
?>
<h1 class="h3 mb-3">Finalizar compra</h1>
<div class="row g-4">
  <div class="col-lg-7">
    <div class="painel">
      <h2 class="h5">Resumo do pedido</h2>
      <ul class="list-group list-group-flush mb-3">
        <?php foreach ($c['itens'] as $i): ?>
          <li class="list-group-item d-flex justify-content-between px-0">
            <span><?= (int) $i['quantidade'] ?> × <?= e($i['nome']) ?></span>
            <span><?= e(brl($i['subtotal'])) ?></span>
          </li>
        <?php endforeach; ?>
      </ul>
      <div class="d-flex justify-content-between fw-bold fs-5">
        <span>Total</span><span><?= e(brl($c['total'])) ?></span>
      </div>
    </div>
  </div>
  <div class="col-lg-5">
    <form method="post" class="painel">
      <?= csrf_campo() ?>
      <h2 class="h5">Forma de pagamento</h2>
      <?php foreach ($metodos as $valor => $rotulo): ?>
        <div class="form-check my-2">
          <input class="form-check-input" type="radio" name="pagamento" id="pg_<?= e($valor) ?>" value="<?= e($valor) ?>" required>
          <label class="form-check-label" for="pg_<?= e($valor) ?>"><?= e($rotulo) ?></label>
        </div>
      <?php endforeach; ?>
      <p class="small text-muted">Pagamento simulado: a confirmação é imediata e nenhum dado financeiro é solicitado.</p>
      <button class="btn btn-destaque w-100" type="submit">Confirmar pagamento de <?= e(brl($c['total'])) ?></button>
      <a class="d-block text-center mt-2" href="<?= e(url('carrinho.php')) ?>">Voltar ao carrinho</a>
    </form>
  </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
