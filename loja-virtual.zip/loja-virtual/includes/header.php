<?php
require_once __DIR__ . '/bootstrap.php';
$titulo = $titulo ?? 'Fliperama Games';
$qtdCarrinho = carrinho_quantidade_total();
$usuario = usuario_atual();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($titulo) ?> · Fliperama Games</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;700&display=swap" rel="stylesheet">
  <link href="<?= e(url('assets/css/style.css')) ?>" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-fliper">
  <div class="container">
    <a class="navbar-brand marca" href="<?= e(url('index.php')) ?>">Fliperama<span>Games</span></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu"
            aria-controls="menu" aria-expanded="false" aria-label="Abrir menu">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="menu">
      <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-2">
        <?php if (eh_admin()): ?>
          <li class="nav-item"><a class="nav-link" href="<?= e(url('admin/index.php')) ?>">Painel admin</a></li>
        <?php endif; ?>
        <li class="nav-item">
          <a class="nav-link" href="<?= e(url('carrinho.php')) ?>">
            Carrinho <?php if ($qtdCarrinho): ?><span class="badge badge-carrinho"><?= (int) $qtdCarrinho ?></span><?php endif; ?>
          </a>
        </li>
        <?php if ($usuario): ?>
          <li class="nav-item"><span class="nav-link disabled">Olá, <?= e(explode(' ', $usuario['nome'])[0]) ?></span></li>
          <li class="nav-item"><a class="nav-link" href="<?= e(url('logout.php')) ?>">Sair</a></li>
        <?php else: ?>
          <li class="nav-item"><a class="nav-link" href="<?= e(url('login.php')) ?>">Entrar</a></li>
          <li class="nav-item"><a class="btn btn-sm btn-destaque" href="<?= e(url('cadastro.php')) ?>">Criar conta</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
<main class="container py-4">
<?php foreach (pegar_flash() as $f): ?>
  <div class="alert alert-<?= e($f['tipo']) ?> alert-dismissible fade show" role="alert">
    <?= e($f['msg']) ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
  </div>
<?php endforeach; ?>
