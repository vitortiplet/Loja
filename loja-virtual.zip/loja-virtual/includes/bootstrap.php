<?php
/**
 * Inicialização comum: .env, banco, sessão e funções auxiliares.
 */
require_once __DIR__ . '/../config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
    session_start();
}

/* ---------- Utilidades ---------- */

/** Escapa texto para HTML (prevenção de XSS). */
function e($valor): string
{
    return htmlspecialchars((string) $valor, ENT_QUOTES, 'UTF-8');
}

/** Monta URL a partir do APP_URL do .env. */
function url(string $caminho = ''): string
{
    return rtrim(env('APP_URL', ''), '/') . '/' . ltrim($caminho, '/');
}

function redirecionar(string $caminho): void
{
    header('Location: ' . url($caminho));
    exit;
}

function brl($valor): string
{
    return 'R$ ' . number_format((float) $valor, 2, ',', '.');
}

function imagem_produto(array $p): string
{
    return empty($p['imagem'])
        ? url('assets/img/placeholder.svg')
        : url('assets/img/produtos/' . rawurlencode($p['imagem']));
}

/* ---------- Mensagens flash ---------- */

function flash(string $tipo, string $mensagem): void
{
    $_SESSION['flash'][] = ['tipo' => $tipo, 'msg' => $mensagem];
}

function pegar_flash(): array
{
    $m = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $m;
}

/* ---------- CSRF ---------- */

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_campo(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

/** Chame no início de todo tratamento de POST. */
function csrf_verificar(): void
{
    $enviado = $_POST['csrf'] ?? '';
    if (!is_string($enviado) || !hash_equals(csrf_token(), $enviado)) {
        http_response_code(403);
        exit('Requisição inválida (token CSRF). Volte e tente novamente.');
    }
}

/* ---------- Autenticação e controle de acesso ---------- */

function usuario_atual(): ?array
{
    return $_SESSION['usuario'] ?? null;
}

function eh_admin(): bool
{
    return (usuario_atual()['perfil'] ?? '') === 'admin';
}

function exigir_login(string $proxima = ''): void
{
    if (!usuario_atual()) {
        flash('warning', 'Faça login para continuar.');
        redirecionar('login.php' . ($proxima ? '?next=' . urlencode($proxima) : ''));
    }
}

/** Validação no servidor: só administradores acessam /admin. */
function exigir_admin(): void
{
    if (!usuario_atual()) {
        flash('warning', 'Faça login para acessar o painel.');
        redirecionar('login.php');
    }
    if (!eh_admin()) {
        http_response_code(403);
        exit('Acesso negado: área restrita a administradores.');
    }
}

/* ---------- Carrinho (em $_SESSION['carrinho'] = [produto_id => quantidade]) ---------- */

function carrinho_quantidade_total(): int
{
    return array_sum($_SESSION['carrinho'] ?? []);
}

/**
 * Lê os produtos do carrinho no banco (preço e estoque sempre atuais).
 * Retorna ['itens' => [...], 'total' => float].
 */
function carrinho_detalhado(): array
{
    $carrinho = $_SESSION['carrinho'] ?? [];
    if (!$carrinho) {
        return ['itens' => [], 'total' => 0.0];
    }
    $ids = array_map('intval', array_keys($carrinho));
    $marcadores = implode(',', array_fill(0, count($ids), '?'));
    $st = db()->prepare("SELECT id, nome, preco, estoque, imagem FROM produtos
                         WHERE ativo = 1 AND id IN ($marcadores)");
    $st->execute($ids);

    $itens = [];
    $total = 0.0;
    foreach ($st->fetchAll() as $p) {
        $qtd = (int) $carrinho[$p['id']];
        $p['quantidade'] = $qtd;
        $p['subtotal'] = round((float) $p['preco'] * $qtd, 2);
        $total += $p['subtotal'];
        $itens[] = $p;
    }
    // remove da sessão produtos que não existem mais / foram desativados
    $_SESSION['carrinho'] = array_intersect_key($carrinho, array_flip(array_column($itens, 'id')));
    return ['itens' => $itens, 'total' => round($total, 2)];
}
