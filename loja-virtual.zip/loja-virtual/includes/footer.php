</main>
<footer class="rodape py-4 mt-5">
  <div class="container small">Fliperama Games · projeto acadêmico, pagamentos simulados.</div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= e(url('assets/js/app.js')) ?>"></script>
</body>
</html>
